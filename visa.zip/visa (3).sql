-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 13, 2024 at 08:11 PM
-- Server version: 8.0.31
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `visa`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(110) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
CREATE TABLE IF NOT EXISTS `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(110) NOT NULL,
  `username` varchar(100) NOT NULL,
  `file` varchar(119) NOT NULL,
  `caption` varchar(92) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `user_id`, `username`, `file`, `caption`) VALUES
(6, '4', 'AMn3uVh55', 'uploads/002.jpg', 'id');

-- --------------------------------------------------------

--
-- Table structure for table `progress`
--

DROP TABLE IF EXISTS `progress`;
CREATE TABLE IF NOT EXISTS `progress` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(110) NOT NULL,
  `name` varchar(100) NOT NULL,
  `percent` varchar(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `progress`
--

INSERT INTO `progress` (`id`, `user_id`, `name`, `percent`) VALUES
(4, '3', 'Bank of America', '20'),
(5, '4', 'done', '100'),
(6, '4', 'Schaden', '7');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `age` varchar(9) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `citizenship` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `destination` varchar(100) DEFAULT NULL,
  `children` varchar(9) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `education_training` text,
  `work_history` text,
  `entry_profile` text,
  `job_offer` varchar(255) DEFAULT NULL,
  `family_or_friends_in_canada` varchar(3) DEFAULT NULL,
  `graduate` varchar(3) DEFAULT NULL,
  `addition` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `first_name`, `last_name`, `title`, `gender`, `age`, `status`, `country`, `citizenship`, `state`, `zipcode`, `destination`, `children`, `language`, `education_training`, `work_history`, `entry_profile`, `job_offer`, `family_or_friends_in_canada`, `graduate`, `addition`) VALUES
(4, 'AMn3uVh55', 'ccrutz@2ueyyj.com', 'DwQmKAJdQ', '2024-09-11 10:34:04', 'Chanelle', 'Stracke', 'MASTER', 'Male', '113', 'MARRIED', 'AQ', 'AQ', 'Arizona', '73875', 'NO PREFERENCE', 'YES', 'ENGLISH', 'YES', 'ut repellat vero', 'NO', 'YES', 'NO', 'YES', '0on  4564 Mraz Fort'),
(3, 'Mackenzie_Schiller', 'your.email+fakedata31373@gmail.com', 'c_RYHrjNHjqcQdP', '2024-09-10 10:47:59', 'Willow', 'Kovacek', 'MR', '1', '527', 'COUPLE', 'UY', 'UY', 'Maine', '4568', 'MANITOBA', '0', 'ENGLISH', 'YES', 'quaerat cupiditate ab', 'YES', 'YES', 'YES', 'YES', '51815 Franecki Orchard');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
